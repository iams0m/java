package 상속;

public class Car extends Object {
	String color;

	public void drive() {
		System.out.println("운전하다.");
	}

}
