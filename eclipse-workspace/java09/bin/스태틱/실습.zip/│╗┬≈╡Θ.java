package 상속;

public class 내차들 {

	public static void main(String[] args) {
		CoffeTruck c = new CoffeTruck();
		c.color = "초록";
		c.period = 3;
		c.space();
	}

}
