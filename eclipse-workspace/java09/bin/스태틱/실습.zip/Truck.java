package 상속;

public class Truck extends Car {
	int period;
	
	public void oiling() {
		System.out.println("주유중입니다.");
	}
}
